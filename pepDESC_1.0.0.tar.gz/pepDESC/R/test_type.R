#' Title test_raw
#'
#' a vector describing the subtype of 27 samples in test_raw
#'
"test_type"
